interface PropsType {
  children?: any;
  addClass?: string;
}

export default PropsType;
