interface PropsType {
  list: Array<string>;
  placeholder: string;
}

export default PropsType;
