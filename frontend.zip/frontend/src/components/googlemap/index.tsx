import GoogleMap from './GoogleMap';

export default GoogleMap;
