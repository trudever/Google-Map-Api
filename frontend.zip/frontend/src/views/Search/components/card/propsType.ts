export interface PropsType {
  index: number;
  data: any;
}
