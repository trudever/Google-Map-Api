import LabelInput from './LabelInput';

export default LabelInput;
