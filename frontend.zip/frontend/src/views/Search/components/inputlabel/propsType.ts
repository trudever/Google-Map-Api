interface PropsType {
  label: string;
  children: any;
  addClass?: string;
}

export default PropsType;
