import PaginationBar from './Pagination';

export default PaginationBar;
