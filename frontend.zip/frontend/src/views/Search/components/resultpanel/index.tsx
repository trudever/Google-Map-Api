import ResultPanel from './ResultPanel';

export default ResultPanel;
