import SelectPanel from './SelectPanel';

export default SelectPanel;
