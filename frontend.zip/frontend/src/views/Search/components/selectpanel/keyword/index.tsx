import Input from './KeywordInput';

export default Input;
