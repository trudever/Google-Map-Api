interface PropsType {
  placeholder: string;
  addClass?: string;
}

export default PropsType;
